Reshade官方地址:
https://reshade.me/
窝只是简单的用Reshade的安装程序给gamemd安装了一下，本包旨在为一些不会安装Reshade（毕竟是嘤文）的小白提供帮助，没什么技术含量（）
食用方法:扔到gamemd.exe同目录后启动游戏即可，游戏内按home（键盘上的）可以调用出Reshade的控制台（）
本压缩包制作者:星空赤影